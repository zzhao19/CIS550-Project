// Private. Will not be included in submission
// Replace <Your Pennkey> and <Your Password>
module.exports = {
  host: "cis550-proj-g50.cps9o1mq3nv1.us-east-1.rds.amazonaws.com",
  user: "admin",
  password: "cis550group50",
  database: "comics"
};
